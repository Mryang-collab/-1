<?php
/**
 * @package   AkeebaReleaseSystem
 * @copyright Copyright (c)2010-2019 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

defined('_JEXEC') or die;

/** @var  \Akeeba\ReleaseSystem\Site\View\Latest\Html  $this */
?>
<div class="ars-categories-{{ $section }}">
	@unless(empty($title))
		<div class="page-header">
			<h2>@lang($title)</h2>
		</div>
	@endunless

	@if(empty($this->categories))
		<p class="muted ars-no-items">
			@lang('ARS_NO_CATEGORIES')
		</p>
	@else
		@foreach($this->vgroups as $vgroup)
			@unless($vgroup->numitems[$section] == 0)
				<div class="ars-vgroup-{{{ $vgroup->id }}}">
					@unless(empty($vgroup->title))
						<h3 class="ars-vgroup-{{{ $vgroup->id }}}-title">
							{{{ $vgroup->title }}}
						</h3>

						@unless(empty($vgroup->description))
							<div class="ars-vgroup-{{{ $vgroup->id }}}-description">
								{{ $vgroup->description }}
							</div>
						@endunless
					@endunless

					@foreach($this->categories->filter(function ($item)
						{
							return \Akeeba\ReleaseSystem\Site\Helper\Filter::filterItem($item, true);
						}) as $id => $item)
						@unless($item->vgroup_id != $vgroup->id)
							@if(($item->type == $section) || ($section == 'all'))
								@include('site:com_ars/Latest/category', ['id' => $id, 'item' => $item, 'Itemid' => $this->Itemid])
							@endif
						@endunless
					@endforeach
				</div>
			@endunless
		@endforeach
	@endif
</div>
