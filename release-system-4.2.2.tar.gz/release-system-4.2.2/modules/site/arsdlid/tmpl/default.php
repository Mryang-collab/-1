<?php
/**
 * @package   AkeebaReleaseSystem
 * @copyright Copyright (c)2010-2019 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

defined('_JEXEC') or die();

?>
<?php echo $params->get('pretext', ''); ?>
	<p style="font-weight: bold;">
		<?php echo $dlid; ?>
	</p>
<?php echo $params->get('posttext', ''); ?>
