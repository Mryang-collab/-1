<?php
/**
 * @package   AkeebaReleaseSystem
 * @copyright Copyright (c)2010-2019 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

/**
 * This file is only required for type hinting in phpStorm for Joomla! 3.4+
 */

class JRegistry extends Joomla\Registry\Registry {}