<?php
/**
 * @package   AkeebaReleaseSystem
 * @copyright Copyright (c)2010-2019 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

defined('_JEXEC') or die;

/** @var  \Akeeba\ReleaseSystem\Admin\View\ControlPanel\Html $this */

$pointsJavascript = '';
$min = null;
$max = null;

foreach ($this->monthlyDailyReport as $pointDate => $pointDownloads)
{
	$min            = is_null($min) ? $pointDate : $min;
	$max            = $pointDate;
	$pointDate      = $this->escape($pointDate);
	$pointDownloads = (int) $pointDownloads;

	$pointsJavascript .= <<< JS
dlPoints.push(['$pointDate', parseInt('$pointDownloads' * 100) * 1 / 100]);

JS;
}

$js = <<< JS

akeeba.jQuery(document).ready(function ($)
{
	$.jqplot.config.enablePlugins = true;
	var dlPoints = [];
	{$pointsJavascript}


	plot1 = $.jqplot('mdrChart', [dlPoints], {
		show:         true,
		axes:         {
			xaxis: {
			    min:          '{$min}',
			    max:          '{$max}',
				renderer:     $.jqplot.DateAxisRenderer
			},
			yaxis: {min: 0, tickOptions: {formatString: '%u'}}
		},
		series:       [
			{
				lineWidth:       3,
				markerOptions:   {
					style: 'filledCircle',
					size:  8
				},
				renderer:        $.jqplot.hermiteSplineRenderer,
				rendererOptions: {steps: 60, tension: 0.6}
			}
		],
		highlighter:  {sizeAdjust: 7.5},
		axesDefaults: {useSeriesColor: true}
	});
});

JS;


?>

@section('graphs')
	{{--@css('media://com_ars/css/jquery.jqplot.min.css')--}}
	@js('media://com_ars/js/jquery.jqplot.min.js')
	@js('media://com_ars/js/jqplot.dateAxisRenderer.min.js')
	@js('media://com_ars/js/jqplot.hermite.js')
	@js('media://com_ars/js/jqplot.highlighter.min.js')
	@js('media://com_ars/js/jquery.colorhelpers.min.js')

	<div class="akeeba-panel--info">
		<header class="akeeba-block-header">
			<h3>@lang('COM_ARS_CPANEL_DLSTATSMONTHLY_LABEL')</h3>
		</header>

		<div id="mdrChart"></div>
	</div>

	<div class="akeeba-panel--info">
		<header class="akeeba-block-header">
			<h3>@lang('COM_ARS_CPANEL_DLSTATSDETAILS_LABEL')</h3>
		</header>

		<table class="akeeba-table--striped">
			<tr>
				<td class="dlstats-label">
					@lang('COM_ARS_CPANEL_DL_EVER_LABEL')
				</td>
				<td>
					<?php echo number_format($this->downloadsEver, 0) ?>
				</td>
			</tr>
			<tr>
				<td class="dlstats-label">
					@lang('COM_ARS_CPANEL_DL_THISMONTH_LABEL')
				</td>
				<td>
					<?php echo number_format($this->downloadsMonth, 0) ?>
				</td>
			</tr>
			<tr>
				<td class="dlstats-label">
					@lang('COM_ARS_CPANEL_DL_THISWEEK_LABEL')
				</td>
				<td>
					<?php echo number_format($this->downloadsWeek, 0) ?>
				</td>
			</tr>
		</table>
	</div>

	<div class="akeeba-panel--info">
		<header class="akeeba-block-header">
			<h3>@lang('COM_ARS_CPANEL_POPULAR_WEEK_LABEL')</h3>
		</header>

		<?php if (empty($this->popularInWeek)): ?>
		<p>
			@lang('COM_ARS_COMMON_NOITEMS_LABEL')
		</p>
		<?php else: ?>
		@foreach($this->popularInWeek as $item)
			<div class="dlpopular">
				<div class="dlbasic">
					<a class="dltitle"
					   href="index.php?option=com_ars&view=download&id=<?php echo (int)$item->item_id ?>">
						{{{ $item->title }}}
					</a>
					<span class="dltimes">
						{{ (int) $item->dl }}
					</span>
				</div>
				<div class="dladvanced">
					<span class="dlcategory">
						{{{ $item->category }}}
					</span>
					<span class="dlversion">
						{{{ $item->version }}}
					</span>
				</div>
			</div>
		@endforeach
		<?php endif; ?>
	</div>
		@inlineJs($js)
@stop
